using System;
using System.Collections.Generic;
using System.Text;

using PHP.Core;
using System.Collections;

namespace CSharpConsole
{
	class Program
	{
		static void Main(string[] args)
		{
			// Initialize the Phalanger context 
			ScriptContext ctx = ScriptContext.CurrentContext;
			ctx.Output = Console.Out;

			// Load the compiled 'xml.php' script file
			Type library_representative = typeof(PhpXmlReader);
			ctx.IncludeScript("xml.php", library_representative);

			// Call a function declared in PHP in 'xml.php' file
			ctx.Call("printLatestNews");
			Console.ReadLine();
		}
	}
}
