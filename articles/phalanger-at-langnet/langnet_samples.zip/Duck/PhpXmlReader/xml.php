<?

function printLatestNews()
{
	$xml = simplexml_load_file("http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml");
	echo "Title: ".$xml->rss->channel->title."\n";
	echo "Link: ".$xml->rss->channel->link."\n";

	echo "\nLatest news:\n";
	foreach($xml->rss->channel->item as $item) 
	{
		echo "  - ".$item->title."\n";
	}
}

?>