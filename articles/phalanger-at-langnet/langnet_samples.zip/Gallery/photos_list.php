<?
	// Photo listing 
	//   photos_list.php?loc=dir  - list files in the directory
	//   photos_list.php?loc=     - list directories in the 'photos' dir
	
	header('Cache-Control: no-cache');

	$loc = $_GET["loc"];
	$root = $loc == "";
	if (!$root) $dir = "photos/".$loc; else $dir="photos";
	
	
	// Find first file in the directory, so we can return it 
	// as a 'example' photo of the gallery
	function getFirstFile($dir)
	{
		$dh = dir($dir);
		while(($file = $dh->read()) !== false) 
		{
			if (substr($file, 0, 1) != '.')
			{
				$dh->close();
				return $file;
			}
		}
	}
	
	// Write all files in the directory or directories in the root directory
	$dh = dir($dir);
  while(($file = $dh->read()) !== false) 
  {
		if (substr($file, 0, 1) != '.')
		{
			echo "$file\n";
			if ($root) echo getFirstFile("photos/$file")."\n";
		}
  }
  $dh->close();	
?>