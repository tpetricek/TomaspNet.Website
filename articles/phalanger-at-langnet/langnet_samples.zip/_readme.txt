The "_ClientBin" directory contains Phalanger Silverlight Assemblies.
To run the Silverlight samples (Copter, Gallery, Intro) copy the DLL files
to the "ClientBin" subdirectory of all three samples.

Due to the Silverlight issue, the samples cannot be opened locally 
using "file://" url, so you'll need to open them via any web server ("http://").